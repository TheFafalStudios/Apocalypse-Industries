Apocalypse Industries - Polluted Water
Minecraft 1.21.1 + Polytone

PURPOSE
Makes water in the common apocalypse biomes darker, dirtier and more toxic-looking.
Biomes O' Plenty Wasteland is intentionally NOT modified.

TARGETS
Main polluted water:
- minecraft:river
- biomesoplenty:dryland
- biomesoplenty:scrubland
- biomesoplenty:wasteland_steppe
- biomesoplenty:crag
- biomesoplenty:dune_beach
- biomesoplenty:gravel_beach
- terralith:gravel_beach
- minecraft:beach
- minecraft:stony_shore

Cold polluted water:
- biomesoplenty:cold_desert
- minecraft:snowy_beach

Volcanic polluted water:
- biomesoplenty:volcanic_plains

COLORS
Main water:      #4A5A2A
Main water fog:  #151D0E

Cold water:      #4D5C50
Cold water fog:  #18201B

Volcanic water:     #414B25
Volcanic water fog: #151A0E

NOT MODIFIED
- biomesoplenty:wasteland
- oceans
- rare-treat Terralith biomes
- other native Terralith biomes

INSTALL
Put the ZIP in .minecraft/resourcepacks and enable it.
Keep it above other packs that modify biome water colors.
Use F3+T after edits to reload resource packs.

EDITING
JSON files are under:
assets/apocalypse_atmosphere/polytone/biome_modifiers/

Polytone uses decimal RGB color values in the JSON. Hex equivalents are listed above.


SCRUBLAND GRASS
- biomesoplenty:scrubland
- grass color override: #746F4A
- dry, dusty olive-brown; foliage is intentionally unchanged



ATMOSPHERE OVERRIDES
Biome fog / sky / foliage:
- Dusty common apocalypse biomes:
  biomesoplenty:wasteland
  biomesoplenty:wasteland_steppe
  biomesoplenty:dryland
  biomesoplenty:scrubland
  minecraft:river
  minecraft:beach
  minecraft:stony_shore
  biomesoplenty:dune_beach
  biomesoplenty:gravel_beach
  terralith:gravel_beach
  fog: #C4B696
  sky: #959891
  foliage: #6F6A3D

- biomesoplenty:crag
  fog: #B8AEA0
  sky: #8F9498
  foliage: #696743

- Cold polluted biomes:
  biomesoplenty:cold_desert
  minecraft:snowy_beach
  fog: #C0C3BE
  sky: #8C97A3
  foliage: #6B705C

- biomesoplenty:volcanic_plains
  fog: #B09D87
  sky: #8A847E
  foliage: #5F5B34

AMBIENT PARTICLES
- ash in wasteland, wasteland_steppe, dryland, scrubland, crag
  probability: 0.0025
- white_ash in cold_desert
  probability: 0.0018
- heavier ash in volcanic_plains
  probability: 0.004


GLOBAL TOXIC GREEN RAIN
- Overrides assets/minecraft/textures/environment/rain.png.
- This applies to rain visually in ALL biomes rather than maintaining a biome list.
- Rain streaks use an acid/toxic green palette.
- minecraft:rain particles are also tinted green with a Polytone particle modifier.
- Existing polluted water, sky, fog, foliage, grass and ambient-particle rules are unchanged.
