APOCALYPSE INDUSTRIES — WEATHER2 TOXIC RAIN RESOURCE PACK
Minecraft 1.21.1 / Weather2 + CoroUtil

INSTALL
Put this ZIP in your instance's resourcepacks folder and enable it above other packs
that modify Weather2/CoroUtil precipitation textures.

WHAT IT CHANGES
Only the three CoroUtil textures used by Weather2's custom precipitation renderer:
- falling rain streaks
- rain ground splashes
- distant/downpour rain sheets

The new look is bright radioactive yellow-green / acid rain.
This is VISUAL ONLY and does not poison or damage entities.

NOTE
The visual override is global wherever Weather2 uses these rain particles. The six-biome
restriction comes from the companion BOP precipitation datapack, not from the texture pack.
