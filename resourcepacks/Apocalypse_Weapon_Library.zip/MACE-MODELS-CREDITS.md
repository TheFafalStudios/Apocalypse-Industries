# Mace additions (local WIP)
Improved Mace Hammer by GugerOS: https://modrinth.com/resourcepack/better-mace-hammer
Full upstream version tebqtkCe, All Rights Reserved. Local adaptation only; do not publish the merged pack without permission. Base, Breach thorns and Wind Burst models/textures preserved; model selection adapted to the existing installation.
Zephyr Warhammer by jonnyloaf: https://modrinth.com/resourcepack/zephyr-warhammer
Upstream zzLFXra4, CC-BY-SA-4.0: https://creativecommons.org/licenses/by-sa/4.0/
Changes: namespaced assets; mace-only Zephyr Warhammer rename via Polytone/CIT. No global item renaming. Zephyr-derived assets retain CC-BY-SA-4.0.
