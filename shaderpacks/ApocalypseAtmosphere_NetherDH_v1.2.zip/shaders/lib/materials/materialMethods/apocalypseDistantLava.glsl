// Shared irregular lava detail for both normal and DH terrain.
// Arithmetic hash avoids the previous repeating diagonal sine bands.
float AiLavaHash(vec2 cell) {
    vec3 q = fract(vec3(cell.x, cell.y, cell.x) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

float AiLavaNoise(vec2 position) {
    vec2 cell = floor(position);
    vec2 part = fract(position);
    part = part * part * (3.0 - 2.0 * part);
    float a = AiLavaHash(cell);
    float b = AiLavaHash(cell + vec2(1.0, 0.0));
    float c = AiLavaHash(cell + vec2(0.0, 1.0));
    float d = AiLavaHash(cell + vec2(1.0, 1.0));
    return mix(mix(a, b, part.x), mix(c, d, part.x), part.y);
}

vec3 GetApocalypseDistantLava(vec3 worldPos) {
    vec2 basePosition = worldPos.xz;
    float flowTime = frameTimeCounter * 0.75;
    // A rotating noise gradient bends the texture into irregular local eddies.
    // Time moves the sampling coordinates, never the overall color or emission.
    vec2 flowPosition = basePosition * 0.045 + vec2(flowTime * 0.21, -flowTime * 0.17);
    float gradientX = AiLavaNoise(flowPosition + vec2(0.25, 0.0))
                    - AiLavaNoise(flowPosition - vec2(0.25, 0.0));
    float gradientZ = AiLavaNoise(flowPosition + vec2(0.0, 0.25))
                    - AiLavaNoise(flowPosition - vec2(0.0, 0.25));
    vec2 curl = vec2(gradientZ, -gradientX) * 12.0;
    vec2 position = basePosition + curl + vec2(flowTime * 0.65, -flowTime * 0.40);
    float coarse = AiLavaNoise(position * 0.04 + vec2(17.3, -8.1));
    float medium = AiLavaNoise(position * 0.18 + vec2(-31.7, 24.6) + vec2(flowTime * 0.11, flowTime * 0.09));
    float fine = AiLavaNoise(position * 4.0 + vec2(3.2, 61.9));
    // Fade sub-block detail with pixel footprint instead of aliasing at long range.
    float footprint = max(length(dFdx(basePosition)), length(dFdy(basePosition)));
    float fineVisibility = 1.0 - smoothstep(0.125, 0.75, footprint);
    float detail = 0.30 * coarse + 0.70 * medium;
    detail = mix(detail, 0.65 * detail + 0.35 * fine, fineVisibility);
    float brightness = mix(0.90, 1.03, detail);
    vec3 lavaColor = mix(vec3(1.0, 0.305, 0.023), vec3(1.0, 0.335, 0.027), detail);
    return lavaColor * brightness;
}
