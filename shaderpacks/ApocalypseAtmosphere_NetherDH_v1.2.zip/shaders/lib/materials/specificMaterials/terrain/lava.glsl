color.rgb *= 0.84;

#ifdef NETHER
    vec3 worldPos = playerPos + cameraPosition;
    vec2 lavaPos = (floor(worldPos.xz * 16.0) + worldPos.y * 32.0) * 0.000666;
    vec2 wind = vec2(frameTimeCounter * 0.012, 0.0);

    float noiseSample = texture2DLod(noisetex, lavaPos + wind, 0.0).g;
    noiseSample = noiseSample - 0.5;
    noiseSample *= 0.1;
    color.rgb = pow(color.rgb, vec3(1.0 + noiseSample));
#endif

noDirectionalShading = true;
lmCoordM = vec2(0.0);
emission = GetLuminance(color.rgb) * 7.48 + 0.5;

maRecolor = vec3(clamp(pow2(pow2(pow2(smoothstep1(emission * 0.28)))), 0.12, 0.4) * 1.3) * vec3(0.25, vec2(0.175));

#if RAIN_PUDDLES >= 1
    noPuddles = 1.0;
#endif

#if defined NETHER && defined DISTANT_HORIZONS && defined GBUFFERS_TERRAIN
    // Keep original detail until the outer normal-terrain/DH handoff band.
    float aiLavaDistance = max(length(playerPos.xz), abs(playerPos.y));
    float aiLavaBlend = smoothstep(far * 0.75, far * 0.90, aiLavaDistance);
    // Normalize animated texture detail by the current sprite's average brightness.
    // Four mip samples cover its quadrants without sampling adjacent atlas sprites.
    vec2 aiSpriteRadius = max(absMidCoordPos, vec2(0.5) / vec2(atlasSize));
    vec2 aiSpritePixels = aiSpriteRadius * 2.0 * vec2(atlasSize);
    float aiSpriteLod = max(0.0, log2(max(1.0, min(aiSpritePixels.x, aiSpritePixels.y))) - 1.0);
    vec2 aiQuarter = aiSpriteRadius * 0.5;
    vec3 aiFrameAverage = (
        texture2DLod(tex, midCoord + vec2(-aiQuarter.x, -aiQuarter.y), aiSpriteLod).rgb +
        texture2DLod(tex, midCoord + vec2( aiQuarter.x, -aiQuarter.y), aiSpriteLod).rgb +
        texture2DLod(tex, midCoord + vec2(-aiQuarter.x,  aiQuarter.y), aiSpriteLod).rgb +
        texture2DLod(tex, midCoord + vec2( aiQuarter.x,  aiQuarter.y), aiSpriteLod).rgb
    ) * 0.25;
    float aiTextureLuma = GetLuminance(colorP);
    float aiFrameLuma = max(GetLuminance(aiFrameAverage), 0.001);
    float aiTextureDetail = pow(clamp(aiTextureLuma / aiFrameLuma, 0.55, 1.55), 0.45);
    vec3 aiStableLava = GetApocalypseDistantLava(playerPos + cameraPosition);
    color.rgb = aiStableLava * mix(aiTextureDetail, 1.0, aiLavaBlend);
    // Keep animated frames from pumping the whole lava ocean's emissive brightness.
    emission = 3.0;
    maRecolor = vec3(0.0);
    noVanillaAO = true;
#endif
