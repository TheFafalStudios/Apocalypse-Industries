// Keep lower-sky gap camouflage at the same distance through every fog/bloom pass.
float GetNetherGapDistance(vec3 viewPosition) {
    float horizon = max(1.0, min(renderDistance, NETHER_VIEW_LIMIT));
    vec3 ray = normalize(mat3(gbufferModelViewInverse) * viewPosition);
    if (isEyeInWater == 0 && cameraPosition.y > 100.0 && ray.y < -0.0001) {
        return min((100.0 - cameraPosition.y) / ray.y, horizon);
    }
    return horizon;
}
