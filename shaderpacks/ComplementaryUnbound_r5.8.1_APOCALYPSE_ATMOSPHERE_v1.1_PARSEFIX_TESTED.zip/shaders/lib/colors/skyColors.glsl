#ifndef INCLUDE_SKY_COLORS
    #define INCLUDE_SKY_COLORS

    #ifdef OVERWORLD
        vec3 skyColorSqrt = sqrt(skyColor);
        // Doing these things because vanilla skyColor gets to 0 during a thunderstorm
        float invRainStrength2 = (1.0 - rainStrength) * (1.0 - rainStrength);
        vec3 skyColorM = mix(max(skyColorSqrt, vec3(0.63, 0.67, 0.73)), skyColorSqrt, invRainStrength2);
        vec3 skyColorM2 = mix(max(skyColor, sunFactor * vec3(0.265, 0.295, 0.35)), skyColor, invRainStrength2);

        #ifdef SPECIAL_BIOME_WEATHER
            vec3 nmscSnowM = inSnowy * vec3(-0.1, 0.3, 0.6);
            vec3 nmscDryM = inDry * vec3(-0.1, -0.2, -0.3);
            vec3 ndscSnowM = inSnowy * vec3(-0.25, -0.01, 0.25);
            vec3 ndscDryM = inDry * vec3(-0.05, -0.09, -0.1);
        #else
            vec3 nmscSnowM = vec3(0.0), nmscDryM = vec3(0.0), ndscSnowM = vec3(0.0), ndscDryM = vec3(0.0);
        #endif
        #if RAIN_STYLE == 2
            vec3 nmscRainMP = vec3(-0.15, 0.025, 0.1);
            vec3 ndscRainMP = vec3(-0.125, -0.005, 0.125);
            #ifdef SPECIAL_BIOME_WEATHER
                vec3 nmscRainM = inRainy * ndscRainMP;
                vec3 ndscRainM = inRainy * ndscRainMP;
            #else
                vec3 nmscRainM = ndscRainMP;
                vec3 ndscRainM = ndscRainMP;
            #endif
        #else
            vec3 nmscRainM = vec3(0.0), ndscRainM = vec3(0.0);
        #endif
        vec3 nuscWeatherM = vec3(0.1, 0.0, 0.1);
        vec3 nmscWeatherM = vec3(-0.1, -0.4, -0.6) + vec3(0.0, 0.06, 0.12) * noonFactor;
        vec3 ndscWeatherM = vec3(-0.15, -0.3, -0.42) + vec3(0.0, 0.02, 0.08) * noonFactor;

        // Apocalypse Industries: persistent industrial haze.
        // This file is included at global shader scope, so every calculation
        // below is expressed as a declaration initializer.
        #ifdef SPECIAL_BIOME_WEATHER
            float aiDustFactor = inDry * invRainFactor;
        #else
            float aiDustFactor = 0.0;
        #endif

        float aiPollutionFactor = clamp01(0.22 + 0.18 * rainFactor + 0.14 * aiDustFactor);
        vec3 aiUpperTint  = mix(vec3(0.92, 0.96, 0.90), vec3(0.77, 0.81, 0.79), rainFactor);
        vec3 aiMiddleTint = mix(vec3(1.03, 0.96, 0.80), vec3(0.80, 0.82, 0.79), rainFactor);
        vec3 aiHorizonTint = mix(
            mix(vec3(1.13, 0.93, 0.67), vec3(0.82, 0.81, 0.75), rainFactor),
            vec3(1.16, 0.91, 0.59),
            0.45 * aiDustFactor
        );

        vec3 aiNoonUpRaw = pow(skyColorM, vec3(2.9))
                         * (vec3(0.85, 0.92, 0.81) + rainFactor * nuscWeatherM);
        vec3 aiNoonMiddleRaw = pow(skyColorM, vec3(1.5))
                             * (vec3(1.3) + rainFactor * (nmscWeatherM + nmscRainM + nmscSnowM + nmscDryM))
                             + aiNoonUpRaw * 0.65;
        vec3 aiNoonDownRaw = skyColorM
                           * (vec3(0.9) + rainFactor * (ndscWeatherM + ndscRainM + ndscSnowM + ndscDryM))
                           + aiNoonUpRaw * 0.25;

        float aiNoonUpLuma = dot(aiNoonUpRaw, vec3(0.2126, 0.7152, 0.0722));
        float aiNoonMiddleLuma = dot(aiNoonMiddleRaw, vec3(0.2126, 0.7152, 0.0722));
        float aiNoonDownLuma = dot(aiNoonDownRaw, vec3(0.2126, 0.7152, 0.0722));

        vec3 noonUpSkyColor = mix(
            aiNoonUpRaw,
            aiNoonUpLuma * aiUpperTint,
            aiPollutionFactor * 0.48
        );
        vec3 noonMiddleSkyColor = mix(
            aiNoonMiddleRaw,
            aiNoonMiddleLuma * aiMiddleTint,
            aiPollutionFactor * 0.72
        );
        vec3 noonDownSkyColor = mix(
            aiNoonDownRaw,
            aiNoonDownLuma * aiHorizonTint,
            aiPollutionFactor
        );

        vec3 sunsetUpSkyColor = skyColorM2
                              * (vec3(0.72, 0.522, 0.47) + vec3(0.1, 0.2, 0.35) * rainFactor2);
        vec3 sunsetMiddleSkyColor = skyColorM2
                                  * (vec3(1.8, 1.3, 1.2) + vec3(0.15, 0.25, -0.05) * rainFactor2);

        vec3 aiSunsetDownRawP = vec3(1.45, 0.86, 0.5) - vec3(0.8, 0.3, 0.0) * rainFactor;
        vec3 aiSunsetDownRaw = aiSunsetDownRawP * 0.5 + 0.25 * sunsetMiddleSkyColor;
        float aiSunsetDownLuma = dot(aiSunsetDownRaw, vec3(0.2126, 0.7152, 0.0722));
        vec3 aiSunsetTint = mix(vec3(1.20, 0.78, 0.43), vec3(0.84, 0.78, 0.69), rainFactor);

        vec3 sunsetDownSkyColorP = mix(
            aiSunsetDownRawP,
            vec3(1.28, 0.61, 0.27),
            0.22 * invRainFactor
        );
        vec3 sunsetDownSkyColor = mix(
            aiSunsetDownRaw,
            aiSunsetDownLuma * aiSunsetTint,
            0.28 + 0.20 * rainFactor
        );

        vec3 dayUpSkyColor     = mix(noonUpSkyColor, sunsetUpSkyColor, invNoonFactor2);
        vec3 dayMiddleSkyColor = mix(noonMiddleSkyColor, sunsetMiddleSkyColor, invNoonFactor2);
        vec3 dayDownSkyColor   = mix(noonDownSkyColor, sunsetDownSkyColor, invNoonFactor2);

        vec3 nightColFactor = 0.9 * vec3(0.07, 0.14, 0.24)
                            * (1.0 - 0.5 * rainFactor) + skyColor;
        vec3 aiNightUpRaw = pow(nightColFactor, vec3(0.90)) * 0.45;
        vec3 aiNightMiddleRaw = sqrt(aiNightUpRaw) * 0.65;
        vec3 aiNightDownRaw = aiNightMiddleRaw * vec3(0.82, 0.82, 0.88);

        float aiNightUpLuma = dot(aiNightUpRaw, vec3(0.2126, 0.7152, 0.0722));
        float aiNightMidLuma = dot(aiNightMiddleRaw, vec3(0.2126, 0.7152, 0.0722));
        float aiNightDownLuma = dot(aiNightDownRaw, vec3(0.2126, 0.7152, 0.0722));

        vec3 nightUpSkyColor = mix(
            aiNightUpRaw,
            aiNightUpLuma * vec3(0.76, 0.82, 0.86),
            0.24
        );
        vec3 nightMiddleSkyColor = mix(
            aiNightMiddleRaw,
            aiNightMidLuma * vec3(0.78, 0.81, 0.82),
            0.28
        );
        vec3 nightDownSkyColor = mix(
            aiNightDownRaw,
            aiNightDownLuma * vec3(0.84, 0.80, 0.72),
            0.30
        );
    #endif

#endif //INCLUDE_SKY_COLORS
