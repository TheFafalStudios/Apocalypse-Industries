vec3 cloudRainColor = mix(nightMiddleSkyColor, dayMiddleSkyColor, sunFactor);

vec3 aiCloudAmbientRaw = mix(
    ambientColor * (sunVisibility2 * (0.55 + 0.17 * noonFactor) + 0.35),
    cloudRainColor * 0.5,
    rainFactor
);
vec3 aiCloudLightRaw = mix(
    lightColor * 1.3,
    cloudRainColor * 0.45,
    noonFactor * rainFactor
);

// Apocalypse Industries: ash-heavy cloud palette.
float aiCloudAmbientLuma = dot(aiCloudAmbientRaw, vec3(0.2126, 0.7152, 0.0722));
float aiCloudLightLuma = dot(aiCloudLightRaw, vec3(0.2126, 0.7152, 0.0722));
vec3 aiCloudAshTint = mix(
    vec3(0.94, 0.91, 0.82),
    vec3(0.73, 0.76, 0.74),
    rainFactor
);

vec3 cloudAmbientColor = mix(
    aiCloudAmbientRaw,
    aiCloudAmbientLuma * aiCloudAshTint,
    0.18 + 0.30 * rainFactor
) * (1.0 - 0.14 * rainFactor);

vec3 cloudLightColor = mix(
    aiCloudLightRaw,
    aiCloudLightLuma * aiCloudAshTint,
    0.12 + 0.24 * rainFactor
) * (1.0 - 0.10 * rainFactor);
