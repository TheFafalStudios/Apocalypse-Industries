OWZA Lite Lost Cities Expansion v0.1.0

Original Lost Cities asset expansion authored for this modpack.
Design target: the large, varied post-apocalyptic city feel associated with OWZA/ChaosZPack,
implemented from scratch using only vanilla Minecraft blocks and The Lost Cities infrastructure.

This pack DOES NOT contain or redistribute OWZA or ChaosZPack structure files.
It uses built-in Lost Cities infrastructure selectors (roads, rails, bridges, parks) by reference.

Minecraft: 1.20.1
The Lost Cities: 1.20-7.5.4 recommended (7.5.0 minimum)
Namespace: owza_lite
Profile file must be installed separately under config/lostcities/profiles/owza_lite.json
