Big Lost City biome compatibility datapack

Purpose:
- Makes Big Lost City structures spawn in Apocalypse Industries / Terralith biomes.
- Leaves an easy control point: edit the biome tag JSON files in:
  data/apocalypse_blc/tags/worldgen/biome/

Tags used:
- apocalypse_blc:city_core      -> major buildings, houses, warehouses, skyscrapers
- apocalypse_blc:city_deco      -> deco pieces and ferris wheel
- apocalypse_blc:city_loose     -> cars and tents
- apocalypse_blc:city_coastal   -> shipping containers on beaches/coasts

How to customize:
- Add or remove biome IDs inside those tag files.
- Example biome IDs:
  biomesoplenty:wasteland
  biomesoplenty:wasteland_steppe
  biomesoplenty:dead_forest
  terralith:desert_canyon
  terralith:bryce_canyon
  minecraft:desert

Install:
- Put the zip in your world's datapacks folder or the instance default datapacks location.
- Create a NEW world for reliable structure changes.

Spawn density:
- This version overrides Big Lost City structure_set spacing with the AGGRESSIVE preset.
- See SPAWN_DENSITY_CONTROL.txt and density_presets/.
