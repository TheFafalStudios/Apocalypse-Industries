Big Lost City Apocalypse / Aggressive / Bearding + CITY CLUSTERS

This pack is based directly on:
big_lost_city_apocalypse_biome_compat_AGGRESSIVE_bearding.zip

WHAT CHANGED
- Existing biome compatibility is preserved.
- Existing beard_thin terrain adaptation is preserved.
- Existing aggressive small/deco/car/tent/house/container structure sets are preserved.
- Standalone generation is disabled for:
  black skyscraper
  red skyscraper
  tall skyscraper
  ruined black skyscraper
  ruined skyscraper
  ruined red skyscraper
  power plant
- Those large structures now generate through apocalypse_blc:city_cluster.

CITY CLUSTERS
- 4 to 9 large buildings per district.
- Cluster-size weights: 4/5/6/7/8/9 = 1/2/3/3/2/1.
- 6-7 building districts are therefore most common.
- Lots are on a 64-block grid.
- Buildings attach by their footprint center and use rollable vertical jigsaws,
  so each selected BLC building may rotate independently.
- The original BLC NBT building templates are referenced directly; they are not duplicated or modified.
- Power plants are rarer filler than skyscrapers.

PLACEMENT
- city_cluster structure set: spacing 42 chunks, separation 14 chunks.
- This intentionally keeps roughly the same aggressive cadence as the previous large-building sets,
  but concentrates buildings into recognizable city districts.
- Structure biome tag: #apocalypse_blc:city_core
- terrain_adaptation: beard_thin

TESTING
Use NEW chunks / a fresh test world.
Try:
  /locate structure apocalypse_blc:city_cluster_4
  /locate structure apocalypse_blc:city_cluster_9

Existing generated chunks will not be changed.
Your flat-terrain placement restriction remains important because a 3x3 district spans about 190 blocks.

COLD DESERT PATCH
- Large city clusters now use #apocalypse_blc:city_cluster_biomes.
- That tag inherits #apocalypse_blc:city_core and explicitly includes biomesoplenty:cold_desert.
- Cluster density and layout are unchanged.

