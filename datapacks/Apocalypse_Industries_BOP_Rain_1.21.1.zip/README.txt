Apocalypse Industries - BOP Rain
Minecraft 1.21.1 / NeoForge 21.1.x

Enables precipitation for:
- biomesoplenty:wasteland
- biomesoplenty:wasteland_steppe
- biomesoplenty:dryland
- biomesoplenty:scrubland
- biomesoplenty:crag
- biomesoplenty:cold_desert

Install:
1. Place this ZIP in <world>/datapacks/
2. Fully restart/reopen the world or server.
3. Test with /weather rain.

Implementation:
The pack overrides the BOP 1.21.1 biome registry JSONs while preserving their
worldgen/spawns/effects and setting has_precipitation=true. Upstream BOP 1.21.1
already has precipitation enabled for crag; it is included to explicitly enforce
the requested state.
