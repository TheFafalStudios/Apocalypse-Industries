Apocalypse Industries - Rare Livestock Spawns v1
Minecraft 1.21.1 / NeoForge

INSTALL:
1. Put this ZIP directly in:
   <world>/datapacks/
2. Restart the world/server (preferred) or run /reload.
3. Check /datapack list and confirm the pack is enabled.

WHAT IT DOES:
- Removes NATURAL biome spawning for:
  cow, pig, chicken, sheep, horse, donkey, llama
  from the common/barren apocalypse biomes.
- Does NOT delete animals already in the world.
- Does NOT block breeding, spawn eggs, /summon, structure/quest placement, etc.
- Leaves the current Terralith RARE TREAT biomes untouched, so their native
  animal spawn tables still work.

RARE TREAT BIOMES LEFT UNTOUCHED:
  - terralith:desert_oasis
  - terralith:red_oasis
  - terralith:tropical_jungle
  - terralith:jungle_mountains
  - terralith:moonlight_valley
  - terralith:moonlight_grove
  - terralith:amethyst_rainforest
  - terralith:amethyst_canyon
  - terralith:yellowstone
  - terralith:mirage_isles
  - terralith:orchid_swamp
  - terralith:blooming_plateau
  - terralith:blooming_valley
  - terralith:bryce_canyon
  - terralith:haze_mountain
  - terralith:hot_shrubland
  - terralith:highlands
  - terralith:lush_valley
  - terralith:scarlet_mountains
  - terralith:snowy_cherry_grove
  - terralith:yosemite_cliffs
  - terralith:yosemite_lowlands

NOTES:
- This pack matches the current Apocalypse Industries remapping where the main
  BOP replacements are wasteland, wasteland_steppe, dryland, scrubland,
  cold_desert, crag, dune_beach and volcanic_plains.
- Terralith bryce_canyon is intentionally treated as a RARE TREAT and is NOT
  in the suppression list.
