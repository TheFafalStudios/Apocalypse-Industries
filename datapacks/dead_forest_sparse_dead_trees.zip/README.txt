Sparse Dead Forest Trees datapack
Target: Minecraft 1.21.1 + Biomes O' Plenty 21.1.x

What it changes
- Removes oak and spruce from biomesoplenty:dead_forest
- Removes oak and spruce from biomesoplenty:old_growth_dead_forest
- Reduces total tree density by roughly 70-75%
- Keeps only dead/dying BOP tree variants

Density controls
Edit:
  data/biomesoplenty/worldgen/placed_feature/trees_dead_forest.json
  data/biomesoplenty/worldgen/placed_feature/trees_old_growth_dead_forest.json

The first placement object is minecraft:count.
Current settings:
- Dead Forest: usually 0 trees/chunk, sometimes 1 (average ~0.6/chunk)
- Old Growth Dead Forest: usually 1 tree/chunk, sometimes 2 (average ~1.5/chunk)

Original BOP values were approximately:
- Dead Forest: 2-3 trees/chunk
- Old Growth Dead Forest: 5-6 trees/chunk

For denser generation, increase the "data" values in the weighted_list.
For sparser generation, decrease them.

Changes only affect newly generated chunks.
